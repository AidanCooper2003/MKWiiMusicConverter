Instructions:

0. Install Audacity if not already installed.
1. Go into audacity, go to edit, then preferences, then modules, then change "mod-script-pipe" from "new" to "enabled." Then, restart audacity.
2. Put any files you want to convert into the "IN" folder.
3. Go to https://www.python.org/ftp/python/3.12.3/python-3.12.3-amd64.exe and download and install Python.
4. Now that Python is installed, "MKWiiMusicConverter.py" should default to opening with Python. Open the file with Python and ensure Audacity is currently open.
4.5. If it ran with Python but had an error, search up "cmd" in the search bar, right click on command prompt and select "run as administrator." Then copy the filepath for your folder, and in command prompt do "cd" followed by a space and then the path. Then do the command "python MKWiiMusicConverter.py".
5. Enter the values as prompted in the python file.
6. Your edited files will now be in the "OUT" folder!

Note: If there are still errors even after installing python and running cmd as administrator,
try restarting audacity.